const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 𝐼𝑁𝐹𝑂𝑅𝑀𝐴𝐶𝐼𝑂𝑁 〉*
   ╽
   ┠≽ *Nombre* : ${pushname}
   ┠≽ *XP* : ${reqXp}
   ┠≽ *Dinero* : ${uangku}
   ┠≽ *Registrado : ✔️
   ┠≽ *REGLAS
   ┠≽ *No Privado Al Bot
   ┠≽ *No Pedir Muchos Comandos Por Minuto
   ╿
┯┷ *〈 𝐼𝑁𝐹𝑂 𝐷𝐸𝐿 𝐵𝑂𝑇 〉*
╽
┠≽ *Prefijo* : 「  ${prefix}  」
┠≽ *Creador* : ${ownerName}
┠≽ *Version* : 4
┠≽ *Canal* : https://youtube.com/channel/UCqCaZ_SEhSykF3-PR5os7YA
╿
┷┯ *〈 𝑀𝐸𝑁𝑈 〉*
   ┠≽ *${prefix}logomakermenu* (𝐿𝑜𝑔𝑜 𝑀𝑒𝑛𝑢)
   ┠≽ *${prefix}imagemakermenu* (𝐼𝑚𝑎𝑔𝑒𝑛 𝑀𝑒𝑛𝑢)
   ┠≽ *${prefix}stickermakermenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑆𝑡𝑖𝑐𝑘𝑒𝑟)
   ┠≽ *${prefix}searchmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐵𝑢𝑠𝑞𝑢𝑒𝑑𝑎)
   ┠≽ *${prefix}educationmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐸𝑑𝑢𝑐𝑎𝑐𝑖𝑜𝑛)
   ┠≽ *${prefix}kerangmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑃𝑟𝑒𝑔𝑢𝑛𝑡𝑎𝑠)
   ┠≽ *${prefix}downloadermenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐷𝑒𝑠𝑐𝑎𝑟𝑔𝑎𝑠)
   ┠≽ *${prefix}mememenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑀𝑒𝑚𝑒𝑠)
   ┠≽ *${prefix}groupmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒𝑙 𝐺𝑟𝑢𝑝𝑜)
   ┠≽ *${prefix}soundmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑆𝑜𝑛𝑖𝑑𝑜𝑠)
   ┠≽ *${prefix}musicmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑀𝑢𝑠𝑖𝑐𝑎)
   ┠≽ *${prefix}islammenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐼𝑠𝑙𝑎𝑚)
   ┠≽ *${prefix}stalkmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐵𝑢𝑠𝑐𝑎𝑟 𝐸𝑛 𝑅𝑒𝑑𝑒𝑠)
   ┠≽ *${prefix}wibumenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑊𝑖𝑏𝑢)
   ┠≽ *${prefix}18+menu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑃𝑜𝑟𝑛𝑜)
   ┠≽ *${prefix}funmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐷𝑖𝑣𝑒𝑟𝑠𝑖𝑜𝑛)
   ┠≽ *${prefix}todmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑉𝑒𝑟𝑑𝑎𝑑 𝑂 𝑅𝑒𝑡𝑜)
   ┠≽ *${prefix}informationmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐼𝑛𝑓𝑜𝑟𝑚𝑎𝑐𝑖𝑜𝑛)
   ┠≽ *${prefix}stayonscreenmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐴𝐹𝐾)
   ┠≽ *${prefix}xpmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑋𝑃)
   ┠≽ *${prefix}limitmenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝐿𝑖𝑚𝑖𝑡𝑒𝑠)
   ┠≽ *${prefix}ownermenu* (𝑀𝑒𝑛𝑢 𝐷𝑒𝑙 𝐶𝑟𝑒𝑎𝑑𝑜𝑟)
   ┠≽ *${prefix}othermenu* (𝑀𝑒𝑛𝑢 𝐷𝑒 𝑂𝑡𝑟𝑜𝑠)
   ╿ *${ownerName}*,
   ╰╼≽  © ${botName}
   *〈 𝐆𝐑𝐔𝐏𝐎𝐒 〉*
   ┠≽ *Félix bot: https://bit.ly/39tPICH
   ┠≽ *Mr-Pato 2: https://bit.ly/3wiL04v
   ┠≽ *Satan bot: https://bit.ly/39v9M7K
   ╰╼
   
   `
}
exports.help = help
